import com.example.javabd.HelloApplication;

public class FakeMain {
    public static void main(String[] args){
        HelloApplication.main(args);
    }
}
